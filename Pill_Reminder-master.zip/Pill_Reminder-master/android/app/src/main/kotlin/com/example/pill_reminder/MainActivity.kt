package com.example.pill_reminder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
